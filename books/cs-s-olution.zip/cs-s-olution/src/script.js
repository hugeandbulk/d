// Inspired by this image from Pinterest: 
// https://www.pinterest.com/pin/505951339380592190/