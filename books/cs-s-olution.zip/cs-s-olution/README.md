# CS(S)olution

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/YzaXwYq](https://codepen.io/josetxu/pen/YzaXwYq).

Inspired by this image from Pinterest:   
 - https://www.pinterest.com/pin/505951339380592190/