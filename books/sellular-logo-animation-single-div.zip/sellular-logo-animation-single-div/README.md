# Sellular Logo Animation | Single div

A Pen created on CodePen.io. Original URL: [https://codepen.io/NaveenPantra/pen/wvjzZMB](https://codepen.io/NaveenPantra/pen/wvjzZMB).

